<?php
	$host = "localhost";
	$user = "id10706995_robotikaitn";
	$pass = "labrobotikaitn19";
	$data_base   = "id10706995_db_weblab";
	$db = mysqli_connect($host, $user, $pass, $data_base);
	
	if(mysqli_connect_errno()){
		echo "Database Not Connected".mysqli_connect_error();
	}
?>